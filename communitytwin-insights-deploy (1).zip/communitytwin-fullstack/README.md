# CommunityTwin — full-stack community issue reporting

A responsive community reporting website with a Flask backend, SQLite database, account registration/sign-in, photo attachments, map-pinned reports, report support votes, status labels, filters, and dynamic map issue discovery through OpenStreetMap/Overpass.

## What is included

- **OpenStreetMap + Leaflet:** map tiles and interactive map; no Google Maps SDK or Google Maps API key.
- **Dynamic area search:** searches places with OpenStreetMap's Nominatim geocoder; the area isn't selected from a hard-coded dropdown.
- **Mapped issue discovery:** queries Overpass for mapped hazards, `fixme` notes, construction, flood-prone features and a couple of other explicit tags within the visible map bounds.
- **Real backend:** Flask API, SQLite database, password hashing, session login, persistent reports and votes.
- **Photo reports:** JPG, PNG and WebP uploads up to 8 MB; photo preview; issue pin selected by clicking the map.
- **Useful user features:** geolocation (permission required), category/status/search filters, support votes, report status, map/list synchronization and responsive layout.
- **Optional status-management API:** protected by `ADMIN_TOKEN` environment variable.

## Run locally

Python 3.10+ is recommended.

### Windows PowerShell

```powershell
cd communitytwin-fullstack
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
python app.py
```

Open **http://127.0.0.1:5000**. The application creates `instance/communitytwin.sqlite3` automatically. You can also use `python -m venv .venv`, activate the environment for your shell, and install requirements on macOS/Linux.

### macOS/Linux

```bash
cd communitytwin-fullstack
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python app.py
```

For real deployment, set environment variables in your hosting dashboard rather than committing secrets. Generate a strong `SECRET_KEY`, set `COOKIE_SECURE=1` behind HTTPS, set `ADMIN_TOKEN`, configure persistent storage for both `DATABASE_PATH` and uploaded photos, and run a production WSGI server, e.g. `gunicorn app:app`. Do not expose Flask debug mode in production.

## Admin status API

Set a private `ADMIN_TOKEN` environment variable. Then send a request like:

```bash
curl -X POST http://127.0.0.1:5000/api/admin/reports/1/status \
  -H 'Content-Type: application/json' \
  -H 'X-Admin-Token: YOUR_ADMIN_TOKEN' \
  -d '{"status":"In progress"}'
```

Allowed statuses: `Open`, `Acknowledged`, `In progress`, `Resolved`, `Closed`. This is a minimal admin API; a production system should add a proper role-based admin dashboard and audit trail.

## API overview

- `GET /api/me` — current signed-in user
- `POST /api/register` — create account (`name`, `email`, `password` JSON)
- `POST /api/login` — sign in (`email`, `password` JSON)
- `POST /api/logout` — sign out
- `GET /api/reports` — list/filter reports (`category`, `status`, `q`, `limit`)
- `POST /api/reports` — multipart report form (`title`, `description`, `category`, `latitude`, `longitude`, `location_name`, optional `photo`); requires sign-in
- `POST /api/reports/<id>/vote` — toggle support vote; requires sign-in
- `GET /api/area-issues?south=...&west=...&north=...&east=...` — discover explicit OSM issue tags in a map bounding box
- `POST /api/admin/reports/<id>/status` — set status with admin token

## Important limitations / production checklist

1. **OSM issue discovery is not an all-knowing issue detector.** It finds only objects tagged by OpenStreetMap contributors in specific ways. It does not retrieve every pothole, illegal dumping site, resident complaint or municipal ticket. No area is hard-coded, but mapped issue coverage varies considerably. For reliable city-wide issue feeds, integrate official municipal open-data APIs or build verified community submissions.
2. Nominatim and Overpass are shared public services with usage policies, rate limits and occasional outages. This demo sends requests from the server for Overpass; geocoding runs from the browser. For high traffic, use an appropriate hosted provider or your own instance and follow their policies.
3. This is a functional starter application, not a security-audited production deployment. Before public launch add CSRF protections, email verification/password reset, rate limiting, moderation/report-abuse tools, photo malware/content scanning, retention policy, backups, and privacy/terms pages. Keep secrets out of source control.
4. Uploaded images are stored on local disk. On ephemeral hosting use persistent object storage and persistent database storage. SQLite is suitable for a small pilot; consider PostgreSQL for multiple application instances or heavier traffic.
5. Community-submitted reports are user-generated content. The UI should not be interpreted as a verified emergency or official municipal service.
6. External CDN assets and map/geocoding providers require internet access. Map attribution is retained.


## Area insights from external open data

The Area insights panel requests weather context from the Open-Meteo forecast API for the selected area's coordinates. It displays current modelled temperature/wind and near-term rain probability, with cautious contextual text. It does not claim to detect or confirm incidents. The map also queries OpenStreetMap/Overpass for features explicitly tagged as hazards, construction, flood-prone areas or map notes. If there are no community reports, these independent data sources can still offer context, but coverage is incomplete and depends on external availability and local mapping.

## Public deployment (Render)

A `render.yaml` Blueprint is included. Push this folder to a GitHub repository, sign in to Render, create a new Blueprint, and connect the repository. Render builds the project and assigns a public `https://<service-name>.onrender.com` URL. See the [official Flask deployment guide](https://render.com/docs/deploy-flask). The public URL does not exist until you deploy it from your own hosting account.

**Production storage warning:** this starter uses SQLite and local `uploads/` storage. On hosting platforms, local disk may be ephemeral and may not be shared across instances. Configure a persistent disk for both database and uploads, or migrate to managed PostgreSQL plus object storage before relying on it for real public community reports. Free hosting can sleep while idle. Set a strong `SECRET_KEY` and review authentication, abuse prevention, privacy and moderation before launch.
