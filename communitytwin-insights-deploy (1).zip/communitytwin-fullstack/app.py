import os, re, json, sqlite3, secrets
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from urllib.parse import quote

import requests
from flask import Flask, request, jsonify, render_template, session, redirect, url_for, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / 'instance'
UPLOAD_DIR = BASE_DIR / 'uploads'
INSTANCE_DIR.mkdir(exist_ok=True)
UPLOAD_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'dev-only-change-this-secret-before-deploying')
app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = str(UPLOAD_DIR)
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = os.getenv('COOKIE_SECURE', '0') == '1'
DB_PATH = os.getenv('DATABASE_PATH', str(INSTANCE_DIR / 'communitytwin.sqlite3'))
ADMIN_TOKEN = os.getenv('ADMIN_TOKEN', '')
ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'webp'}
ISSUE_TYPES = {'Pothole', 'Garbage', 'Streetlight', 'Waterlogging', 'Road damage', 'Water leak', 'Blocked drain', 'Unsafe area', 'Other'}
STATUSES = {'Open', 'Acknowledged', 'In progress', 'Resolved', 'Closed'}


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


def init_db():
    with db() as con:
        con.executescript('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            latitude REAL NOT NULL,
            longitude REAL NOT NULL,
            location_name TEXT NOT NULL,
            photo_filename TEXT,
            status TEXT NOT NULL DEFAULT 'Open',
            created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
            reporter_name TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            votes INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS votes (
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            report_id INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
            created_at TEXT NOT NULL,
            PRIMARY KEY (user_id, report_id)
        );
        CREATE INDEX IF NOT EXISTS idx_reports_created ON reports(created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_reports_location ON reports(latitude, longitude);
        ''')


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    with db() as con:
        row = con.execute('SELECT id, name, email FROM users WHERE id = ?', (uid,)).fetchone()
        return dict(row) if row else None


def report_dict(row, user_id=None):
    d = dict(row)
    d['photo_url'] = f"/uploads/{quote(d['photo_filename'])}" if d.get('photo_filename') else None
    d['created_at_display'] = d.get('created_at', '')[:16].replace('T', ' ')
    d['has_voted'] = False
    if user_id:
        with db() as con:
            d['has_voted'] = con.execute('SELECT 1 FROM votes WHERE user_id=? AND report_id=?', (user_id, d['id'])).fetchone() is not None
    return d


def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get('user_id'):
            return jsonify(error='Please sign in to do that.'), 401
        return fn(*args, **kwargs)
    return wrapped


def allowed_image(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.get('/')
def index():
    return render_template('index.html', user=current_user())


@app.get('/api/me')
def api_me():
    return jsonify(user=current_user())


@app.post('/api/register')
def register():
    data = request.get_json(silent=True) or request.form
    name = str(data.get('name', '')).strip()
    email = str(data.get('email', '')).strip().lower()
    password = str(data.get('password', ''))
    if len(name) < 2 or len(name) > 70:
        return jsonify(error='Name must be between 2 and 70 characters.'), 400
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email):
        return jsonify(error='Enter a valid email address.'), 400
    if len(password) < 8:
        return jsonify(error='Password must be at least 8 characters.'), 400
    try:
        with db() as con:
            cur = con.execute('INSERT INTO users(name,email,password_hash,created_at) VALUES(?,?,?,?)',
                              (name, email, generate_password_hash(password), now_iso()))
            session['user_id'] = cur.lastrowid
        return jsonify(user=current_user()), 201
    except sqlite3.IntegrityError:
        return jsonify(error='An account with this email already exists.'), 409


@app.post('/api/login')
def login():
    data = request.get_json(silent=True) or request.form
    email = str(data.get('email', '')).strip().lower()
    password = str(data.get('password', ''))
    with db() as con:
        user = con.execute('SELECT * FROM users WHERE email=?', (email,)).fetchone()
    if not user or not check_password_hash(user['password_hash'], password):
        return jsonify(error='Incorrect email or password.'), 401
    session.clear()
    session['user_id'] = user['id']
    return jsonify(user=current_user())


@app.post('/api/logout')
def logout():
    session.clear()
    return jsonify(ok=True)


@app.get('/api/reports')
def get_reports():
    category = request.args.get('category', '').strip()
    status = request.args.get('status', '').strip()
    search = request.args.get('q', '').strip()[:100]
    area = request.args.get('area', '').strip()[:120]
    limit = min(max(int(request.args.get('limit', 200)), 1), 500)
    clauses, params = [], []
    if category and category in ISSUE_TYPES:
        clauses.append('category=?'); params.append(category)
    if status and status in STATUSES:
        clauses.append('status=?'); params.append(status)
    if search:
        clauses.append('(title LIKE ? OR description LIKE ? OR location_name LIKE ?)')
        term = f'%{search}%'; params.extend([term, term, term])
    if area:
        clauses.append('location_name LIKE ?'); params.append(f'%{area}%')
    where = (' WHERE ' + ' AND '.join(clauses)) if clauses else ''
    with db() as con:
        rows = con.execute(f'SELECT * FROM reports{where} ORDER BY CASE status WHEN "Open" THEN 0 WHEN "In progress" THEN 1 ELSE 2 END, created_at DESC LIMIT ?', (*params, limit)).fetchall()
        totals = con.execute("SELECT COUNT(*) total, SUM(CASE WHEN status='Open' THEN 1 ELSE 0 END) open_count, SUM(CASE WHEN status='In progress' THEN 1 ELSE 0 END) progress_count, SUM(CASE WHEN status='Resolved' THEN 1 ELSE 0 END) resolved_count FROM reports").fetchone()
    uid = session.get('user_id')
    return jsonify(reports=[report_dict(r, uid) for r in rows], stats={k: (totals[k] or 0) for k in totals.keys()})


@app.post('/api/reports')
@login_required
def create_report():
    title = request.form.get('title', '').strip()
    description = request.form.get('description', '').strip()
    category = request.form.get('category', 'Other').strip()
    location_name = request.form.get('location_name', '').strip()[:180]
    try:
        lat, lon = float(request.form.get('latitude', '')), float(request.form.get('longitude', ''))
    except (TypeError, ValueError):
        return jsonify(error='Choose the issue location on the map first.'), 400
    if not (-90 <= lat <= 90 and -180 <= lon <= 180):
        return jsonify(error='The selected coordinates are invalid.'), 400
    if not title or len(title) > 120:
        return jsonify(error='Title is required and must be under 120 characters.'), 400
    if len(description) < 10 or len(description) > 2000:
        return jsonify(error='Description must be between 10 and 2,000 characters.'), 400
    if category not in ISSUE_TYPES:
        category = 'Other'
    photo_filename = None
    photo = request.files.get('photo')
    if photo and photo.filename:
        if not allowed_image(photo.filename):
            return jsonify(error='Photo must be JPG, PNG, or WebP.'), 400
        ext = secure_filename(photo.filename).rsplit('.', 1)[1].lower()
        photo_filename = f'{secrets.token_hex(16)}.{ext}'
        photo.save(UPLOAD_DIR / photo_filename)
    user = current_user()
    timestamp = now_iso()
    with db() as con:
        cur = con.execute('''INSERT INTO reports(title,description,category,latitude,longitude,location_name,photo_filename,status,created_by,reporter_name,created_at,updated_at)
                             VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
                          (title, description, category, lat, lon, location_name or f'{lat:.5f}, {lon:.5f}', photo_filename, 'Open', user['id'], user['name'], timestamp, timestamp))
        row = con.execute('SELECT * FROM reports WHERE id=?', (cur.lastrowid,)).fetchone()
    return jsonify(report=report_dict(row, user['id'])), 201


@app.post('/api/reports/<int:report_id>/vote')
@login_required
def vote_report(report_id):
    uid = session['user_id']
    with db() as con:
        exists = con.execute('SELECT 1 FROM reports WHERE id=?', (report_id,)).fetchone()
        if not exists:
            return jsonify(error='Report not found.'), 404
        vote = con.execute('SELECT 1 FROM votes WHERE user_id=? AND report_id=?', (uid, report_id)).fetchone()
        if vote:
            con.execute('DELETE FROM votes WHERE user_id=? AND report_id=?', (uid, report_id))
            con.execute('UPDATE reports SET votes=MAX(0,votes-1) WHERE id=?', (report_id,))
            voted = False
        else:
            con.execute('INSERT INTO votes(user_id,report_id,created_at) VALUES(?,?,?)', (uid, report_id, now_iso()))
            con.execute('UPDATE reports SET votes=votes+1 WHERE id=?', (report_id,))
            voted = True
        count = con.execute('SELECT votes FROM reports WHERE id=?', (report_id,)).fetchone()['votes']
    return jsonify(voted=voted, votes=count)


@app.post('/api/admin/reports/<int:report_id>/status')
def update_status(report_id):
    if not ADMIN_TOKEN or request.headers.get('X-Admin-Token', '') != ADMIN_TOKEN:
        return jsonify(error='Admin access is not configured or token is invalid.'), 403
    data = request.get_json(silent=True) or {}
    status = data.get('status')
    if status not in STATUSES:
        return jsonify(error='Invalid status.'), 400
    with db() as con:
        cur = con.execute('UPDATE reports SET status=?,updated_at=? WHERE id=?', (status, now_iso(), report_id))
        if cur.rowcount == 0:
            return jsonify(error='Report not found.'), 404
    return jsonify(ok=True, status=status)


@app.get('/api/area-issues')
def area_issues():
    """Search OSM/Overpass for mapped issue features in the selected bounding box.
    This is not a municipal complaint feed and only finds items explicitly mapped in OSM.
    """
    try:
        south = float(request.args.get('south', ''))
        west = float(request.args.get('west', ''))
        north = float(request.args.get('north', ''))
        east = float(request.args.get('east', ''))
    except ValueError:
        return jsonify(error='A valid map bounding box is required.'), 400
    if not (-90 <= south < north <= 90 and -180 <= west < east <= 180):
        return jsonify(error='Invalid map bounding box.'), 400
    # Bound the query size so public services are not asked for huge regions.
    if (north - south) * (east - west) > 3.0:
        return jsonify(error='Zoom in to a smaller area to discover mapped issues.'), 400
    query = f'''[out:json][timeout:18];(
      nwr["hazard"]({south},{west},{north},{east});
      nwr["fixme"]({south},{west},{north},{east});
      nwr["highway"="construction"]({south},{west},{north},{east});
      nwr["flood_prone"="yes"]({south},{west},{north},{east});
      nwr["man_made"="manhole"]["condition"="damaged"]({south},{west},{north},{east});
      nwr["amenity"="waste_disposal"]["disused"="yes"]({south},{west},{north},{east});
    );out center tags 60;'''
    endpoints = ['https://overpass-api.de/api/interpreter', 'https://overpass.kumi.systems/api/interpreter']
    last_error = None
    for endpoint in endpoints:
        try:
            response = requests.post(endpoint, data={'data': query}, timeout=22, headers={'User-Agent': 'CommunityTwin/1.0 (community issue map)'})
            response.raise_for_status()
            elements = response.json().get('elements', [])
            items = []
            for el in elements:
                tags = el.get('tags', {})
                lat = el.get('lat', (el.get('center') or {}).get('lat'))
                lon = el.get('lon', (el.get('center') or {}).get('lon'))
                if lat is None or lon is None:
                    continue
                category = tags.get('hazard') or ('Construction' if tags.get('highway') == 'construction' else 'Flood risk' if tags.get('flood_prone') == 'yes' else 'Map note / fixme')
                name = tags.get('name') or tags.get('description') or tags.get('fixme') or category
                items.append({'id': f"osm-{el.get('type')}-{el.get('id')}", 'title': str(name)[:120], 'category': str(category)[:60], 'latitude': lat, 'longitude': lon, 'source': 'OpenStreetMap', 'tags': {k: v for k, v in tags.items() if k in ['hazard','fixme','highway','flood_prone','name','description']}})
            return jsonify(issues=items, source='OpenStreetMap / Overpass', note='Only explicitly mapped features are returned; this is not a complete list of real-world problems.')
        except Exception as exc:
            last_error = str(exc)
    app.logger.warning('Overpass unavailable: %s', last_error)
    return jsonify(error='The OpenStreetMap issue service is temporarily unavailable. Please try again shortly.', issues=[]), 503



@app.get('/api/insights')
def area_insights():
    """Return contextual weather indicators from Open-Meteo for the selected area."""
    try:
        lat = float(request.args.get('lat', ''))
        lon = float(request.args.get('lon', ''))
    except ValueError:
        return jsonify(error='Valid latitude and longitude are required.'), 400
    if not (-90 <= lat <= 90 and -180 <= lon <= 180):
        return jsonify(error='Coordinates are out of range.'), 400
    try:
        response = requests.get(
            'https://api.open-meteo.com/v1/forecast',
            params={'latitude': lat, 'longitude': lon,
                    'current': 'temperature_2m,precipitation,rain,wind_speed_10m,weather_code',
                    'hourly': 'precipitation_probability,precipitation', 'forecast_days': 1,
                    'timezone': 'auto'},
            timeout=12, headers={'User-Agent': 'CommunityTwin/1.0 (community context insights)'})
        response.raise_for_status()
        data = response.json()
        current = data.get('current', {})
        hourly = data.get('hourly', {})
        probs = hourly.get('precipitation_probability') or []
        rain = hourly.get('precipitation') or []
        now_idx = 0
        if current.get('time') and hourly.get('time'):
            try:
                now_idx = hourly['time'].index(current['time'])
            except ValueError:
                pass
        next_probs = probs[now_idx:now_idx+6]
        next_rain = rain[now_idx:now_idx+6]
        max_prob = max(next_probs) if next_probs else None
        total_rain = round(sum(x or 0 for x in next_rain), 1) if next_rain else None
        signals = []
        if max_prob is not None and max_prob >= 60:
            signals.append({'level':'watch', 'title':'Rain watch', 'detail':f'Rain probability reaches {max_prob}% in the next six forecast hours. Check drains and low-lying streets.'})
        elif max_prob is not None:
            signals.append({'level':'info', 'title':'Rain outlook', 'detail':f'Highest rain probability in the next six forecast hours: {max_prob}%. This is weather context, not a flood prediction.'})
        if current.get('wind_speed_10m') is not None and current['wind_speed_10m'] >= 35:
            signals.append({'level':'watch', 'title':'Strong winds', 'detail':f'Current wind speed is {current["wind_speed_10m"]} km/h. Secure loose items and use caution around trees.'})
        if not signals:
            signals.append({'level':'info', 'title':'No strong weather signal', 'detail':'Current forecast indicators show no threshold-triggered weather watch. This does not mean the area is free of hazards.'})
        return jsonify(source='Open-Meteo', attribution='Weather data by Open-Meteo', current={
            'temperature_c': current.get('temperature_2m'), 'rain_mm': current.get('rain'),
            'precipitation_mm': current.get('precipitation'), 'wind_kmh': current.get('wind_speed_10m'),
            'weather_code': current.get('weather_code'), 'time': current.get('time')},
            next_6h={'max_precipitation_probability': max_prob, 'precipitation_total_mm': total_rain},
            signals=signals, disclaimer='These are contextual weather indicators, not verified local incidents or official emergency alerts.')
    except Exception as exc:
        app.logger.info('Open-Meteo insights unavailable: %s', exc)
        return jsonify(error='External weather insights are temporarily unavailable.', source='Open-Meteo', signals=[]), 503


@app.get('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(UPLOAD_DIR, filename, as_attachment=False)


@app.errorhandler(413)
def too_large(_error):
    return jsonify(error='Photo is too large. Maximum upload size is 8 MB.'), 413


@app.errorhandler(500)
def server_error(_error):
    app.logger.exception('Unexpected server error')
    return jsonify(error='Something went wrong on the server.'), 500


init_db()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.getenv('PORT', '5000')), debug=os.getenv('FLASK_DEBUG', '0') == '1')
